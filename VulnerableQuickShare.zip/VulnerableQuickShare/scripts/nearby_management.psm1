function Clear-NearbyShareInstallation {
  # Remove shortcuts in start menu for all users
  Write-Host 'Started to remove shortcuts ...'
  $profiles = Get-WmiObject -Class Win32_UserProfile

  foreach ($profile in $profiles) {
    if ($profile.Special) {
      continue
    }

    $userStartMenuPath = Join-Path -Path $profile.LocalPath -ChildPath `
      'AppData\Roaming\Microsoft\Windows\Start Menu\Programs'
    $shortcuts = Get-ChildItem $userStartMenuPath -Filter *.lnk
    $wshell = New-Object -ComObject WScript.Shell
    foreach ($shortcut in $shortcuts) {
      $s = $wshell.CreateShortcut($shortcut.FullName)
      if ($s.TargetPath -like "$env:ProgramW6432\Google\NearbyShare\*" -or `
          $s.TargetPath -like "$env:ProgramFiles\Google\NearbyShare\*") {
        Remove-Item $shortcut.FullName
      }
    }
  }

  Write-Host 'Completed to remove shortcuts.'
}

function Get-PnpUtil {
  if (Test-Path "$env:SystemRoot\System32\pnputil.exe") {
    return "$env:SystemRoot\System32\pnputil.exe"
  }
  elseif (Test-Path "$env:SystemRoot\SysNative\pnputil.exe") {
    return "$env:SystemRoot\SysNative\pnputil.exe"
  }
  else {
    return $null
  }
}

function Install-IntelDriver {
  Write-Host 'Started to install Intel driver ...'

  $pnputil = Get-PnpUtil
  if ($pnputil -eq $null) {
    Write-Host 'Failed to find pnputil.'
    return
  }

  $PIEInstallationPath = "$env:ProgramW6432\Google\NearbyShare\intel"
  if ( Get-WmiObject Win32_NetworkAdapter | Where-Object { ($_.Name -like `
    '*Intel*' -or $_.Name -like '*Killer*') -and ($_.Name -like '*Wi-Fi*' -or `
    $_.Name -like '*Wireless*' -or $_.Name -like '*Wifi*') } -ne "" ) {
    & $pnputil /add-driver "$PIEInstallationPath\PieExtension.INF" /install | Out-Null
    & $pnputil /add-driver "$PIEInstallationPath\PieComponent.INF" /install | Out-Null
    & $pnputil /scan-devices | Out-Null

    if ( ( & $pnputil /enum-devices | Select-String -Pattern `
      '{4d3c822d-417d-4b03-b562-cd33f5fda354}' -Context 0,6 ) -ne '' ) {
      Write-Host 'Intel PIE SDK successfully installed.'
    }
    else {
      Write-Host 'Intel PIE SDK installation failed.'
    }
  }
  Write-Host 'Completed to install Intel driver.'
}


function Uninstall-IntelDriver {
  Write-Host 'Started to uninstall Intel driver ...'

  $pnputil = Get-PnpUtil
  if ($pnputil -eq $null) {
    Write-Host 'Failed to find pnputil.'
    return
  }

  $oem_inf_name = pnputil.exe /enum-devices | Select-String -Pattern `
    '{4d3c822d-417d-4b03-b562-cd33f5fda354}' -Context 0,6 | ForEach-Object `
    { $_.Context.PostContext -split ': ' } | Select-String `
    -Pattern '.inf' |  ForEach-Object { $_ -replace '^\s+|\s+$|\t+|\r+' }
  if ($oem_inf_name -ne '') {
    & $pnputil /delete-driver $oem_inf_name /uninstall /force | Out-Null
    Write-Host 'Uninstalled Intel PIE SDK !'
  }
  else {
    Write-Host 'No intalled Intel PIE SDK !'
  }
  Write-Host 'Completed to uninstall Intel driver.'
}

Export-ModuleMember -Function Clear-NearbyShareInstallation,Install-IntelDriver,Uninstall-IntelDriver
